var less = {logLevel: 4,
    errorReporting: "console"};
less.rootpath = "https://www.github.com/cloudhead/less.js/";
less.relativeUrls = true;

